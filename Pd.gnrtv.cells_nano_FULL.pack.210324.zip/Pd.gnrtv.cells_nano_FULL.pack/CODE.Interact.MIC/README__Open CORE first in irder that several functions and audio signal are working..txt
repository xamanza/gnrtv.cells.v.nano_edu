Open First gnrtv.cells.nano__CORE to Listen Audio Elements in the rest of .pd patches of Cells.
